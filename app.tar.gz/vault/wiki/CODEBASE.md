# Codebase Map

npm workspaces monorepo at `/home/${username}/websites/${sandboxId}/public_html`. The web app ships standalone. Call `enable_pocketbase_integration` to add a database, or `enable_api_server_integration` to add an Express backend — each tool appends its own `## apps/<service>` section to this file.

## apps/web (React + Vite + Tailwind + shadcn/ui, port 3000)

Located at apps/web/. Run: `cd apps/web && npm run dev` (auto-started by the sandbox supervisor).
index.html — HTML entry point, Crisp live chat script injected in head for all pages
src/main.jsx — entry point, mounts <App />
src/App.jsx — React Router, all routes defined here
src/index.css — Tailwind theme, CSS variables, light comfortable aesthetic with indigo accents, Plus Jakarta Sans typography
src/pages/HomePage.jsx — "/" route, hero banner, product store with package variants (1/7/30 günlük), professional stats (5000+ happy customers, 10000+ completed sales, 4.9/5 rating, "Profesyonel" badge), authentic customer reviews about cheat quality/fast delivery/reliability, comparisons
src/pages/AuthPages.jsx — "/login" and "/register" routes, Turkish auth forms
src/pages/AdminPage.jsx — "/admin" route, comprehensive admin dashboard with 16 menu items (Overview, Products, Banners, Coupons, Blog, Orders, Balance Requests, Setup Support, Giveaways, Support, Comments, Users, Mail History, Categories, Discounts, Pages); Products section includes form for adding/editing products with name, category (PUBG/Apex/Rust/Arc Raiders), description, image upload/URL, video upload/URL, 3 package tiers (1/7/30 günlük) with separate price and stock per tier, stock/price updates, product deletion; Orders, Balance Requests, and Users sections display live data from context
src/pages/ProductPage.jsx — "/product/:id" route, product detail with package selection (1/7/30 günlük), related products from same category, add-to-cart functionality
src/pages/CartPage.jsx — "/cart" route, cart items with package variants, quantity adjustment, remove items, checkout with wallet balance display and payment processing
src/pages/ProfilePage.jsx — "/profile" route, user profile editing (avatar, name, email, bio), wallet balance display, add balance form, balance withdrawal requests, order history
src/components/Layout.jsx — header with cart icon badge, footer, shared layout wrapper, user avatar and profile link; promo bar and discount coupon removed
src/components/ScrollToTop.jsx — resets scroll on route change
src/components/ui/ — shadcn/ui primitives — import from `@/components/ui/<name>`, do not edit the files
src/context/AppContext.jsx — global auth state, user session, admin context, profile editing, product management with 4 categories and 3-tier packages, wallet system (add balance, withdrawal requests), cart management (add/remove items, checkout), order history, balance request tracking
src/data/store.js — seed product catalog with 4 categories (PUBG, Apex, Rust, Arc Raiders), each product has 3 package tiers (1/7/30 günlük) with separate prices and stock, Rust category banner and products use Rust logo image, professional stats (5000+ happy customers, 10000+ completed sales, 4.9/5 rating), authentic customer reviews about cheat quality/fast delivery/reliability, orders, users, balance requests, Hilevadisi branding
src/data/adminData.js — admin panel mock data: categories (PUBG, Apex, Rust, Arc Raiders), empty coupons, banners, blog posts, giveaways, support tickets, comments, mail history, discounts, pages with zero KPI metrics
src/hooks/use-mobile.jsx — mobile breakpoint detection
src/hooks/use-toast.js — toast notifications
src/lib/utils.js — cn() Tailwind class merge
vault/wiki/skills/design/SKILL.md — frontend craft, styling, typography, motion, and shadcn policy for UI surfaces.
apps/web/plugins/session-journal/ — infrastructure, DO NOT edit. Vite dev plugin injects the browser session journal client; events go over HMR (`import.meta.hot.send('session-journal:event', …)`); the plugin arranges persistence under `vault/temp/SESSION_JOURNAL.md`.
Routes: / → HomePage, /login → AuthPages (login), /register → AuthPages (register), /admin → AdminPage, /profile → ProfilePage, /product/:id → ProductPage, /cart → CartPage
